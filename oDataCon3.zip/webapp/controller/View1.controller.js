sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller,History) {
	"use strict";

	return Controller.extend("test.oDataCon3.controller.View1", {

	
		onInit: function () {
			//	this.getRouter().getRoute("View1").attachPatternMatched(this._onObjectMatched, this);
			// var oModel = new sap.ui.model.odata.v2.ODataModel(
			// 	"https://cors-anywhere.herokuapp.com/https://services.odata.org/V2/(S(wa2mmgqdilcodwbaymesotbz))/OData/OData.svc/");
			//  var oMetadata = oModel.getServiceMetadata();
			// this.getView().setModel(oModel, "oModel");
	
		},
			_onObjectMatched: function (oEvent) {

			var context = oEvent.getParameter("arguments").objectId;

			var path = "/" + context;
			var fullPath = "oModel>" + path;

			if (context == undefined) {
				this.onCreate();
			} else {
				this.getView().bindElement(fullPath);
			}
		},
			getRouter : function () {
				return sap.ui.core.UIComponent.getRouterFor(this);
			},
		onRowClick: function (oEvent) {

				var k = oEvent.getSource().getBindingContextPath().split('/')[1];
				this.getRouter().navTo('View2', {
				objectId: k
							// this.getRouter().navTo('RouteView2');

			});
		},

		onClick: function () {

			this.getRouter().navTo('View3');
			
		},

	});
});