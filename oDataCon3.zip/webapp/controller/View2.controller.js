sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function (Controller, History, MessageToast) {
	"use strict";

	return Controller.extend("test.oDataCon3.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.oDataCon3.view.View2
		 */
		onInit: function () {

			this.getRouter().getRoute("View2").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {

			var context = oEvent.getParameter("arguments").objectId;

			var path = "/" + context;
			var fullPath = "oModel>" + path;

			if (context == undefined) {
				this.onCreate();
			} else {
				this.getView().bindElement(fullPath);
			}
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onNavBack: function () {

			this.getRouter().navTo('TargetView1');
		},
		onEdit: function () {
			this.byId('inp1').setProperty('enabled', true);
			this.byId('inp2').setProperty('enabled', true);
			this.byId('inp3').setProperty('enabled', true);
			this.byId('but1').setProperty('enabled', true);
		},
		onSave2: function () {

			var oModel = this.getOwnerComponent().getModel("oModel");

			var input1 = this.byId("inp1").getValue();
			var input2 = this.byId("inp2").getValue();
			var input3 = this.byId("inp3").getValue();

			var oDataM = this.getView().getModel("oModel");
			// var newModel=this.getOwnerComponent().getModel("oModel");
			if (oDataM.hasPendingChanges()) {
				var sPath = this.getView().getBindingContext("oModel").getPath();
				var oNewData = oDataM.getProperty(sPath);

				oDataM.update(sPath, oNewData, {
					success: function () {
						// newModel.setProperty("/editMode", false);
						MessageToast.show("Data Updated");
					},
					error: function () {
						MessageToast.show("Something went wrong while updating");
					}
				});

			}
		},
		onDelete: function () {
			debugger;
			var oDataM = this.getView().getModel("oModel");

			var sPath = this.getView().getBindingContext("oModel").getPath();
			oDataM.remove(sPath, {
				success: function () {
					// newModel.setProperty("/editMode", false);
					MessageToast.show("Data Deleted");
				},
				error: function () {
					MessageToast.show("Something went wrong while deleting");
				}
			});
			// this.getRouter().navTo('View1');	
		}
	});

});