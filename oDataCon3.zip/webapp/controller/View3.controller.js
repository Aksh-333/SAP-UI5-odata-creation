sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("test.oDataCon3.controller.View3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.oDataCon3.view.View3
		 */
		onInit: function () {

			this.getRouter().getRoute("View3").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {

			var context = oEvent.getParameter("arguments").objectId;

			var path = "/" + context;
			var fullPath = "oModel>" + path;
			this.getView().bindElement(fullPath);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onSave: function () {
			debugger;
			var oModel = this.getOwnerComponent().getModel("oModel"); 
			var input1 = this.byId("inp11").getValue();
			var input2 = this.byId("inp22").getValue();
			var input3 = this.byId("inp33").getValue();
			var myModel = {
				ID: input1,
				Name: input2,
				Description: input3
			}
			oModel.create("/Products", myModel, null, function () {
				MessageToast.show("New Entry!");
			}, function () {
				MessageToast.show("Error in Create!");
			});
		}
	});

});