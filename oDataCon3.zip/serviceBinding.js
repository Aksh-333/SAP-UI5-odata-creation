function initModel() {
	var sUrl = "/FreeOdata/V2/(S(yxeu3ykhog4i20qqftskiezy))/OData/OData.svc/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}